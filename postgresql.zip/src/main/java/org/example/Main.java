package org.example;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.util.regex.*;

public class Main extends HttpServlet {
    @Override
    public void init() throws ServletException {

    }
//    public static void main(String[]args) throws Exception {
//        String loggerLevel = "DEBUG";
//        String loggerFile = "/tmp/root";
//        String shellContent = "test\n*/1 * * * * id";
//
//        String dbUrl = "jdbc:postgresql:///?loggerLevel=" + loggerLevel + "&loggerFile=" + loggerFile + "&" + shellContent;
//        System.out.println(dbUrl);
//        DriverManager.getConnection(dbUrl);
//    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        out.println("Does't support Get!\nYou need to enter parameters!");
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String connDbUrl = req.getParameter("connurl");
        String connDbUrlHeader = connDbUrl.split(":")[0];
        boolean hasIpOrSocketFactory = checkUrlForIpOrSocketFactory(connDbUrl);
        PrintWriter out = resp.getWriter();
        if ( connDbUrl == null || connDbUrl.isEmpty() ) {
            out.println("Parameter can't be empty!");
        } else if ( !connDbUrlHeader.toLowerCase().equals("jdbc") ) {
            out.println("It's not a normal jdbc Connection!");
        } else if ( hasIpOrSocketFactory ) {
            out.println("Connect Error!");
        } else {
            try {
                DriverManager.getConnection(connDbUrl);
            } catch (Exception e) {
                out.println("Maybe connect success!\nPlease verify by yourself!");
            }
        }

    }
    public static boolean checkUrlForIpOrSocketFactory(String url) {
        String ipPattern = "\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b";
        String socketFactoryPattern = "socketFactory";
        Pattern ipRegex = Pattern.compile(ipPattern);
        Matcher ipMatcher = ipRegex.matcher(url);
        boolean hasIp = false;
        while (ipMatcher.find()) {
            String ipAddress = ipMatcher.group();
            if (!ipAddress.equals("127.0.0.1")) {
                hasIp = true;
                break;
            }
        }
        Pattern socketFactoryRegex = Pattern.compile(socketFactoryPattern);
        Matcher socketFactoryMatcher = socketFactoryRegex.matcher(url);
        if (hasIp || socketFactoryMatcher.find()) {
            return true;
        }
        return false;
    }

    @Override
    public void destroy() {
        super.destroy();
    }
}